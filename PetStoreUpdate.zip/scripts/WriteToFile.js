﻿var lock = new java.util.concurrent.locks.ReentrantLock();
function writeFile(text) 
{
lock.lock();
var writer = new java.io.FileWriter("c:\\log.txt",true);
writer.write("\r\n");
writer.close();
lock.unlock();
}