﻿var Bedrooms = context.variableManager.getValue ("j_Bedrooms");
var Bathrooms = context.variableManager.getValue ("j_Bathrooms");
var Description = context.variableManager.getValue ("j_Description");
var Amenities = context.variableManager.getValue ("j_Amenities");
var ShortAddress = context.variableManager.getValue ("j_shortAddress");
var Price = context.variableManager.getValue ("j_Price");
var ListingID = context.variableManager.getValue ("j_listingID");
var Hood = context.variableManager.getValue ("j_Hood");
var Status = context.variableManager.getValue ("j_Status");
var SubwayLines = context.variableManager.getValue ("j_SubwayLines");
var SubwayLines = context.variableManager.getValue (" j_AvailableDate");
var lock= new java.util.concurrent.locks.ReentrantLock(); 
//Lock the file so that no two users can write at the same time 
 lock.lock(); 
 //Open the file for writing 
 var writer= new java.io.FileWriter("G:\\\\May\\\\Data1.txt",true); 
 //Write the following text to the above file 
 writer.write(Bedrooms+"\r\n  "+Bathrooms+"\r\n"+Description+"\r\n  "+Amenities+"\r\n  "+ShortAddress+"\r\n  "+Price+"\r\n  "+ListingID+"\r\n  "+Hood+"\r\n  "+Status+"\r\n  "+SubwayLines+" \r\n" ); 
//Close the file 
 writer.close(); 
 //Unlock the lock so that other users can write on it 
 lock.unlock();